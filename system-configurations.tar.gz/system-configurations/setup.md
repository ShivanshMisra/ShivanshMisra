# Using these settings
- Install package 'irqbalance' and then enable it's systemd service
- Enable tsc clocksource (in the kernel parameters) via [Archwiki](https://wiki.archlinux.org/title/Gaming#Improving_performance).
- Optimize Ext4 file system by:-
    1. Enable fast_commit in File system by running `sudo tune2fs -O fast_commit /dev/sdaX' where 'X' is the ext4 file system's block device number.
    2. Change fstab mount options, change mount options to 'rw,noatime,commit=60'.
- Next, You may want to also decrease latency by copying files to their respected location like:-
    1. Move 'tcp-bbr.conf' to /etc/modules-load.d/.
    2. Move 'consistent-response-time-for-gaming.conf' to /etc/tmpfiles.d/
    3. Move 'fast-network.conf' to /etc/sysctl.d/.
- Then, enable additional optimization and speed boosts by following the links:-
    1. [Improving performance](https://wiki.archlinux.org/title/Improving_performance).
    2. [Improving Boot Performance](https://wiki.archlinux.org/title/Improving_performance/Boot_process) and [Silent Boot](https://wiki.archlinux.org/title/Silent_boot).
    3. [Sysctl Wiki Page](https://wiki.archlinux.org/title/Sysctl).
    4. [Reduce Latency](https://wiki.archlinux.org/title/Gaming#Improving_performance) don't implement all the settings here!
- There you go! Finished, I guess!
