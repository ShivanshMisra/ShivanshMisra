# With this archive you have "kali-breezedecoration.so" as a file
## Steps to install it a kde window decoration
- Search for a folder name `org.kde.kdecoration2` inside the /usr/lib/... directory using the find command (This may change in the Future!)
- After doing this copy the `kali-breezedecoration.so` file there with root privilidges and `chmod +x` it, with those root privilidges.
- Voila, your file should be ready, open systemsettings and apply the theme!
