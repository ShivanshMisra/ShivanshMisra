# How to use these files to optimize setup
- The fast-network.conf & tcp-bbr.conf are used to enable fast networking.
- The consistent-response-time-gaming.conf? is used to increase performance however it is not the same as the one on the archwiki as it does not disable transparent huge pages and compaction proactiveness and does not reserve any free bytes, because they do not apply to any of our systems...
- To apply settings copy tcp-bbr.conf to /etc/modules-load.d/
- copy fast-network.conf to /etc/sysctl.d/
- and finally copy consistent-response-time?.conf to /etc/tmpfiles.d/

- Next optimize your setup accordingly and check settings work by using the /proc && /sys dir(s).
